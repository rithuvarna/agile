<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DCS WEBSITE</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/style1.css" rel="stylesheet">


  <!-- =======================================================
  * Template Name: Maxim - v4.7.0
  * Template URL: https://bootstrapmade.com/maxim-free-onepage-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<body>
    <?php include('navigation.php'); ?>
    <div class="dlab-bnr-inr overlay-black-middle bg-pt" style="background-image: url(assets/img/totalav-640x360.jpg)">
        <div class="container">
            <div class="dlab-bnr-inr-entry">
                <h1 class="text-white ">About Us</h1>
                <div class="breadcrumb-row">
                    <ul class="list-inline">
                        <li>
                            <a href="index.html">Home</a>
                            >
                        </li>
                        <li>About Us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div>
    <div class="content">
        <h3>OUR VISION</h3>
            <P>To globally excel in innovative research,teaching, and technology development inspired by social obligation.</P>
        <h3>OUR MISSION</h3>
            <P>To contribute to knowledge development and dissemination.<br>
            To facilitate learning and innovative research in frontier areas of computer science.<br>
            To drive students for technology development to solve problems of interest.<br>
            To create socially responsible professionals.</P>
        <h3>Here's What We Are</h3>
            <p class="p1">The Department of Computer Science came into existence in 1984 with an M.Tech. course in Computer and Information Science, which was the first in the state of Kerala. In 1986, the Department was identified by the Defence Research and Development Organisation for conducting an M.Sc. programme in Computer Software, as a feeder course to the DRDO Laboratories. The department served as a seeding agent for the establishment of Computer Centre, which was inaugurated by the then Prime Minister in 1990,. The department was entrusted with the responsibility of conducting the MCA programme in June 1994, which helped to streamline the course and setting it into the right track. The B.Tech. course started in 1996, was given co-ordinating support by the department in the branch of Computer Science & Engineering. A new M.Tech. programme in Software Engineering sponsored by UGC was also started in the academic year 2000-2001 Ph.D. programme in the areas of Artificial Intelligence, Networking, Information Systems Engineering etc. are being pursued.The department has so far received grants to the tune of Rs. 10 crore from various national agencies. The INFOCUS project with support from the Netherlands Government and collaboration of the Delft University of Technology was co-ordinated by the department jointly.The campus intranet, the CUSAT website, the campus intercom system are all managed by the department.The department provides technical expertise and support to various Government/Quasi-government bodies.</p>
    </div>
</div>
</body>
</html>