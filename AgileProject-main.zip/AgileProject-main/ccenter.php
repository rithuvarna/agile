<!--include the navbar-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DCS WEBSITE</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/style1.css" rel="stylesheet">
  <link href="assets/css/fstyle.css" rel="stylesheet">


  <!-- =======================================================
  * Template Name: Maxim - v4.7.0
  * Template URL: https://bootstrapmade.com/maxim-free-onepage-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<body>
    <?php include('navigation.php'); ?> 
    <div class="div1">
        <table>
            <tbody>
            <tr>
    <td colspan="20"><table width="100%" cellspacing="0" cellpadding="0" bordercolor="#1bac9" border="1">
      <tbody>
        <tr>
          <td><table width="100%" cellspacing="0" cellpadding="0">
                <tbody><tr>
                  <td valign="top" height="0" align="left">
				  




        <br>
        <table width="90%" border="0" align="center">

          <tbody><tr>
            <td class="csstyle2"><strong>Computer Center</strong></td>
          </tr>
          <tr>
            <td class="csstyle2"><div align="center"><img src="cirm2.jpg" width="313" height="197" align="absmiddle"></div></td>
          </tr>
          <tr>
            <td class="csstyle2"><p>The COMPUTER CENTRE of the University was inaugurated in 1990 by the Prime   Minister of India. It was an outcome of the joint efforts of the University and   the Defence Research and Development Organisation of the Government of India.   From 1995 onwards the centre is being looked after completely by the University,   within the administrative control of the Department of Computer Science.</p>
                <!--	Remove this line and enter your page contents here --></td>
          </tr>
          <tr>
		  <td><a href="https://cusat.ac.in/cirm.php" target="_blank"><p style="font-family:verdana;background-color:powderblue;text-align:right;font-size:90%;">Click here for more details...</p></a></td>
            
          </tr>
        </tbody></table>
        
		  </td>
                </tr>
                
              </tbody></table></td>
        </tr>
        <tr> </tr>
      </tbody>
    </table></td>
  </tr>
            </tbody>
        </table>
    </div>
</body>
</html>