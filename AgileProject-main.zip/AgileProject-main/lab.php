<!--include the navbar-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DCS WEBSITE</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/style1.css" rel="stylesheet">
  <link href="assets/css/fstyle.css" rel="stylesheet">


  <!-- =======================================================
  * Template Name: Maxim - v4.7.0
  * Template URL: https://bootstrapmade.com/maxim-free-onepage-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<body>
    <?php include('navigation.php'); ?> 
    <div class="div1">
    <table >
        <tbody>
        <tr>
    <td colspan="20"><table width="100%" cellspacing="0" cellpadding="0" bordercolor="#1bac9" border="1">
      <tbody>
        <tr>
          <td><table width="100%" cellspacing="0" cellpadding="0">
                <tbody><tr>
                  <td valign="top" height="0" align="left">
				  





        <br>
        <table width="90%" border="0" align="center">
          <tbody><tr>
            <td class="csstyle2">DCS has an enchanting physical environment spread over an area of 1500 sq.m, with state of the art laboratories to support the M.Tech programmes, research laboratories (described elsewhere in this brochure), air-conditioned Conference room and Auditorium, well organised library, class rooms, faculty rooms, office et cetra.  Apart from the wi-fi hotspot in the department, all its constituents are provided with access points to the wired net. <br></td>
          </tr>
		  <tr bgcolor="#CCCCCC">
            <td class="csstyle2"><strong>GPU Server Infrastructure</strong></td>
          </tr>
		  <tr>
            <td class="csstyle2"><i>Accelerated Computing Facility catering to present day computing (AI/ML/Big Data) requirements</i></td>
          </tr>
		  <tr>
		    <td colspan="2" class="csstyle2" height="0"><strong>Hardware Facilities</strong></td>
	      </tr>
		  <tr>
		  <td colspan="2" class="csstyle2"><table width="100%" border="0">
                <tbody><tr>
                  <td width="5%">&nbsp;</td>
				  <td class="csstyle2" width="95%">•	<strong>Dell Power Edge  R730 Server</strong><br>
				  • Intel Xeon E5-2620 v3 Hexa Core/16GB DDR4<br>
				  • Nvidia Quadro RTX graphics card<br>
				  • 1TB HDD intermediate storage of working data and results
				  </td>
                </tr>
				
				<tr>
                  <td colspan="2" class="csstyle2"><strong>Software Facilities</strong></td>
                </tr>
				<tr>
                  <td width="5%">&nbsp;</td>
				  <td class="csstyle2" width="95%">•	Ubuntu with Python 3, CUDA 11.x, PyTorch, Tensorflow<br></td>
                </tr></tbody></table></td>
	      </tr>
		  <tr bgcolor="#CCCCCC">
            <td class="csstyle2"><strong>Hyper-Converged Virtualization Infrastructure</strong></td>
          </tr>
		  <tr>
            <td class="csstyle2"><i>A VMware based High Availability Fault Tolerent cluster with bidirectional mirroring that caters to the demand for virtualized multi-site server deployments</i></td>
          </tr>
		  <tr>
		    <td colspan="2" class="csstyle2" height="0"><strong>Hardware Facilities</strong></td>
	      </tr>
		  <tr>
		  <td colspan="2" class="csstyle2"><table width="100%" border="0">
                <tbody><tr>
                  <td width="5%">&nbsp;</td>
				  <td class="csstyle2" width="95%">•	Fujistu Primergy RX2530 M4 Rack Servers<br></td>
                </tr>
				<tr>
                  <td width="5%">&nbsp;</td>
				  <td class="csstyle2" width="95%">•	Cisco 10G Switches, FiberChannel<br></td>
                </tr>
				<tr>
                  <td colspan="2" class="csstyle2"><strong>Software Facilities</strong></td>
                </tr>
				<tr>
                  <td width="5%">&nbsp;</td>
				  <td class="csstyle2" width="95%">•	Academic VMware ESXi vsphere Standard<br></td>
                </tr></tbody></table></td>
		  </tr>
	      <tr bgcolor="#CCCCCC">
            <td class="csstyle2"><strong>High Availability Storage (Direct-Attached Storage) Array</strong></td>
          </tr>
		  <tr>
            <td class="csstyle2"><i>Storage cluster with transparent fail-over support for the HA cluster infrastructure</i></td>
          </tr>
		  <tr>
		    <td colspan="2" class="csstyle2" height="0"><strong>Hardware Facilities</strong></td>
	      </tr>
		  <tr>
		  <td colspan="2" class="csstyle2"><table width="100%" border="0">
                <tbody><tr>
                  <td width="5%">&nbsp;</td>
				  <td class="csstyle2" width="95%">•	Fujistu ETERNUS DX60 S4 Storage <br></td>
                </tr>
				<tr>
                  <td colspan="2" class="csstyle2"><strong>Software Facilities</strong></td>
                </tr>
				<tr>
                  <td width="5%">&nbsp;</td>
				  <td class="csstyle2" width="95%">•	ETERNUS SF Storage Cruiser Standard cluster controller<br></td>
                </tr>
				</tbody></table>
		  </td>
		  </tr>
          <tr bgcolor="#CCCCCC">
            <td class="csstyle2"><strong>	Quantum Computing Lab/ Artificial Intelligence &nbsp;&amp;&nbsp; Natural Language Processing Laboratory (HCI/AI/NLP Lab) </strong></td>
          </tr>
		  <tr>
		    <td colspan="2" class="csstyle2" height="0"><strong>Hardware Facilities</strong></td>
	      </tr>
		  <tr>
            <td colspan="2" class="csstyle2"><table width="100%" border="0">
                <tbody><tr>
                  <td width="5%">&nbsp;</td>
                  <td class="csstyle2" width="95%">• Smash PC- 6Nodes:<br>
				    Onboard Intel Core i5-8250U 1.6 GHz (8th Gen) Max 3.4GHz Four Core Eight Thread processor<br>
				    15 W TDP, ,  8Gb RAM       IOT/Distributed learning 
				   <!-- &bull;	IBM A-Pro Intellistation:<br />
                    Graphics Workstation <br />
                    Dual Core 64 Bit AMD Opteron- Model 275. <br />
                    &bull;	IBM Z-Pro Intellistation:<br />
                    Graphics Workstation <br />
                    Dual Core 64 Bit INTEL Xeon Model 5160 <br />
                    &bull;	HCL Global Line 2750:<br />
                    Server Computer PIV Zeon 1.7 GHz <br />
                    &bull;	Acer Veriton 7500 Desktops, <br />
                    P IV 1.7 GHz, Intel 845 chipset<br />
                    &bull;	HP Color Laserjet 3800 Printer -->
					</td>
                </tr>
                <tr>
                  <td colspan="2" class="csstyle2"><strong>Software Facilities</strong></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td class="csstyle2">•	AUTODESK Motion Builder Pro-7<br>
                    •	Q pointer Voice Speech Recognition Software<br>
                    •	Face Tracking System for Face Gesture 
                    Recognition <br>
                    •	Shape Hand Plus System for capturing full range of wrist, finger &amp; thumb movement</td>
                </tr>
                <tr>
                  <td colspan="2" class="csstyle2"><strong>Live Projects</strong></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td class="csstyle2">•	Malayalam Handwritten Character Recognition<br>
                    •	Malayalam Speech to Text Conversion<br>
                    •	American Sign Language Recognition</td>
                </tr>
            </tbody></table></td>
	      </tr>
		  <tr bgcolor="#CCCCCC">
            <td class="csstyle2"><strong>	Bioinformatics Lab/Artificial Intelligence &nbsp;&amp;&nbsp; Software Engineering Lab
            </strong></td>
	      </tr>
		  <tr>
            <td colspan="2" class="csstyle2" height="0"><strong>Hardware Facilities</strong></td>
	      </tr>
		  <tr>
            <td colspan="2" class="csstyle2"><table width="100%" border="0">
                <tbody><tr>
                  <td width="5%">&nbsp;</td>
                  <!-- <td width="95%" class='csstyle2'>&bull;	<strong>PC /104 based development platform:</strong> <br />
                    Popular standardized small form-factor platform for small computing applications. <br />
                    &bull;	<strong>NI&rsquo;s PXI Controller: </strong><br />
                    Compact PCI system for modular instrumentation and data acquisition applications<br />
                    &bull;<strong>	PowerQuicc II Reference Design: </strong><br />
                    Compact PCI Card for evaluating and prototyping designs<br />
                    &bull;	<strong>Mica Motes: </strong><br />
                    An out-of-the-box wireless sensor network module for rapid prototyping, application development and deployments<br />
                    &bull;<strong>	IBM System x3400:</strong> <br />
                  Dual-Core Dual Intel Xeon based server system <br />
				   &bull;<strong>	Fujitsu workstations:</strong> <br />
				   Quad Core Xeon E3-1240 <br />
				   Quad Core Xeon E5-1600
				  </td> -->
				  <td class="csstyle2" width="95%">•  Acer Veriton M4660G VM4660G-I3810H1 Desktop Computers (7 Nos)<br>
				  </td>
                </tr>
                <tr>
                  <td colspan="2" class="csstyle2"><strong>Software Facilities</strong></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td class="csstyle2"><strong>•	RTLinux :</strong> Operating System for Real-Time / Embedded applications <br>
                    <strong>•	VxWorks</strong> : Real-Time operating system with Tornado IDE<br>
                    <strong>•	LabView </strong>: A visual design tool for measurement analysis &amp; signal processing<br>
                    <strong>•	TinyOS</strong>	  : Development platform for tiny devices</td>
                </tr>
                <tr>
                  <td colspan="2" class="csstyle2"><strong>Live Projects</strong></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td class="csstyle2">•	Middleware and Routing Protocols for Wireless Sensor Networks<br>
                    •	Localization and Tracking for Sensor Networks<br>
                    •	Streaming video for real time applications<br>
                  •	Secure file system for tiny devices </td>
                </tr>
            </tbody></table></td>
	      </tr>
		  <tr bgcolor="#CCCCCC">
            <td class="csstyle2"><strong>Cyber Physical Systems Lab/ Artificial Intelligence &nbsp;&amp;&nbsp; Computer Vision Lab    </strong></td>
	      </tr>
		  <tr>
            <td colspan="2" class="csstyle2" height="0"><strong>Hardware Facilities</strong></td>
	      </tr>
		  <tr>
            <td colspan="2" class="csstyle2"><table width="100%" border="0">
                <tbody><tr>
                  <td width="5%">&nbsp;</td>
                  <!-- <td width="95%" class='csstyle2'>&bull;	IBM X Series Servers<br />
                    &bull;	IBM Thinkpad Laptops with wireless connectivity<br />
                    &bull;	WiFi Access Points<br />
                    &bull;	GSM Modem<br />
                    &bull;	GSM/GPRS &amp; CDMA simulation infrastructure   (to be acquired)<br />
                  &bull;	Programmable Mobile Phones (to be acquired)</td> -->
				  <td class="csstyle2" width="95%">• <strong>Fujitsu workstations</strong>  Quad Core Xeon E3-1240   Quad Core Xeon E5-1600 (6nos)<br>
                  • <strong>Thinkstation P 900</strong>        Intel Xeon E5-2620 2.1 Ghz     4GB DDR3 Memory   1TB SATA HDD (2nos) <br>
                  • <strong>Thinkcentre</strong>  Core i5 processor, 4 GB DDR3 RAM, 500 GB HDD, I TB SATA HDD <br>
				  </td>
                </tr>
                <tr>
                  <td colspan="2" class="csstyle2"><strong>Software Facilities</strong></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td class="csstyle2"><p>• <strong>Montavista Linux </strong><br>
              • <strong>Asterix IP PBX (</strong>to be acquired)<br>
              • <strong>NS2 </strong>Simulation Software<br>
              • <strong>Matlab R2006a</strong><br>
              • <strong>Opensource JAVA/SIP environment</strong><br>
              • <strong>Service Delivery Platform</strong> (to be acquired)<br>
              • <strong>SDK for Windows/Linux Smart Phones</strong> (to be 
              acquired)<br>
             • <strong>Network Simulator software : QualNet</strong> <br></p></td>
                </tr>
                <tr>
                  <td colspan="2" class="csstyle2"><strong>Live Projects</strong></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td class="csstyle2">•	Mobility Modeling of Adhoc Networks<br>
                  •	Service Oriented Architecture for WSNs</td>
                </tr>
            </tbody></table></td>
	      </tr>
		  <!-- <tr>
		    <td colspan="2" class='csstyle2'><table width="100%" border="0">
              <tr bgcolor="#CCCCCC">
                <td colspan="2" bgcolor="#CCCCCC" class='csstyle2'><strong>Software Engineering Laboratory (SEL)</strong></td>
              </tr>
              <tr>
                <td height="0" colspan="2" class='csstyle2'><strong>Hardware Facilities</strong></td>
              </tr>
              <tr>
                <td width="5%">&nbsp;</td>
                <td width="95%" class='csstyle2'>Desktops on Pentium IV Dual Core and Pentium IV </td>
              </tr>
              <tr>
                <td colspan="2" class='csstyle2'>Software Facilities</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                
          <td class='csstyle2'>
                  <strong>&bull;	Microsoft Visual Studio .NET with MSDN</strong><br />
                  An integrated development environment (IDE) for developing web applications, web services, desktop applications, and mobile applications. <br />
                  <strong>&bull;	NetBeans  (freeware)</strong><br />
                  Linux based integrated tool for software development and associated documentation (UML diagrams).<br />
                  <strong>&bull;	Matlab version 7.0</strong><br />
                  Library of signal and image processing routines.<br />
                  <strong>&bull;	Open CV (Computer Vision)</strong><br />
                Intel&rsquo;s open computer vision library for solving various computer vision problems.</td>
              </tr>
              <tr>
                <td colspan="2" class='csstyle2'><strong>Live Projects</strong></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td class='csstyle2'>&bull;	Automated Testing of Object Oriented Software<br />
                  &bull;	Test Sequence Generation <br />
                  &bull;	Moving Object Detection<br />
                  &bull;	Speech Processing<br />
                  &bull;	Question Answering System<br />
                  &bull;	Security Issues in WSN.<br />
                  &bull;	Multimodal Maps<br />
                  &bull;	Software Standards and Process Models<br />
                &bull;	Agent Based Meeting Scheduler </td>
              </tr>
            </table></td>
	      </tr> -->
          <tr bgcolor="#CCCCCC">
            <td class="csstyle2" bgcolor="#CCCCCC"><strong>Computing Lab</strong></td>
          </tr>
          <tr>
            <td class="csstyle2"><i>This well equipped general-purpose Computing lab meets the curricular requirements of the M.Tech programmes.</i></td>
          </tr>
          <tr>
            <td colspan="2" class="csstyle2" height="0"><strong>Hardware Facilities</strong></td>
	      </tr>
		  <tr>
            <td colspan="2" class="csstyle2"><table width="100%" border="0">
                <tbody><tr>
                  <td width="5%">&nbsp;</td>
                  <td class="csstyle2" width="95%">• <strong>Fujistu Celsius Workstation</strong> Intel Xeon (10 Core, 3.30GHz)<br>
                  • 64GB DDR4/NVIDIA Quadro P2000 5GB/2TB SATA <br>
                  • <strong>LENOVO THINK CENTRE</strong> CORE i5 4GB/500GB (14nos) <br>
				  • Core i7/Intel Mother Board/4GB DDR3/1TB SATA/Graphics GPU with 1GB DDR3 on board (3nos)<br>
				  • <strong>Dell Workstation Precision</strong> T 1600 Xeron 3.30 GHZ/8GB DDR3/500GB SDRAM/1TB  500 SATA/1GB NividaGraphics Card (11nos)<br>
				  • Intel Core i3 550/4GB DDR3/500 GB SATA (4nos)<br>
				  • Acer Veriton M4660G VM4660G-I3810H1 (12nos)
				  </td>
                </tr>
                <tr>
                  <td colspan="2" class="csstyle2"><strong>Software Facilities</strong></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td class="csstyle2"><p>• Ptolemy  Modelling and simulation of cyber physical system<br>
             
                                          • Matlab
                  </p></td>
                </tr>
                
            </tbody></table></td>
	      </tr>


</tbody></table>
        
		  </td>
                </tr>
                
              </tbody></table></td>
        </tr>
        <tr> </tr>
      </tbody>
    </table></td>
  </tr>
        </tbody>
    </table>
</div>
</body>
</html>