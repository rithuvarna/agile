<!--include the navbar-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DCS WEBSITE</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/style1.css" rel="stylesheet">
  <link href="assets/css/fstyle.css" rel="stylesheet">


  <!-- =======================================================
  * Template Name: Maxim - v4.7.0
  * Template URL: https://bootstrapmade.com/maxim-free-onepage-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<body>
    <?php include('navigation.php'); ?>
    <div class="div1">
        <table width="100%">
            <tbody>
            <tr>
    <td colspan="20"><table width="100%" cellspacing="0" cellpadding="0" bordercolor="#1bac9" border="1">
      <tbody>
        <tr>
          <td><table width="100%" cellspacing="0" cellpadding="0">
                <tbody><tr>
                  <td valign="top" height="0" align="left">
				  




        <br>
        <table width="90%" border="0" align="center">
          <tbody><tr>
            <td class="csstyle2">The Department Library provides the students an opportunity to tap the latest   information available through a collection of technical journals, magazines,   books, research papers, seminar proceedings and project reports.</td>
          </tr>
          <tr>
            <td class="csstyle2"><ul>
                <li>
                  <p align="left">More than 6000   Technical Books and 60 Journals. </p>
                </li>
              <li>
                  <p align="left">PHD Thesis and   Project report for reference. </p>
              </li>
              <li>
                  <p align="left">Research   Monograms. </p>
              </li>
              <li>
                  <p align="left">ACM membership since   1986. </p>
              </li>
              <li>
                  <p align="left">International and   National Conference proceedings. </p>
              </li>
              <li>
                  <p align="left">Excellent collection   of CDs. </p>
              </li>
              <li>
                  <p align="left">Referance facilty   avail for students outside University also </p>
              </li>
            </ul></td>
          </tr>
          <tr>
            <!--<td height="0" class='csstyle2'><form action="http://172.16.64.22:8080/cgi-bin/koha/opac-search.pl" method="get" name="frm" target="_blank" id="frm">
			<input type="hidden" name="op" value="do_search" />
				<input type="hidden" name="type" value="opac" />
				<input type="hidden" name="marclist" value="" />
				<input type="hidden" name="and_or" value="and" />
				<input type="hidden" name="excluding" value="" />
				<input type="hidden" name="operator" value="contains" />
				
              <div align="center"><font face="arial,helvetica" 
                                size="1">
              <input name="q" type="text" id="value" style=" BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; BORDER-LEFT: 1px solid; COLOR: #999999; BORDER-BOTTOM: 1px solid; " value="Search Department Library Books " size="40" maxlength="30" onfocus="if (this.value==this.defaultValue) this.value='';" />
              </font>
                <font face="arial,helvetica" 
                                size="1">
                <input name="image" type="image" src="images/go_button.gif" align="bottom" width="28" height="21" border="0" />
                </font>                </div>
            </form>            </td>-->
          </tr>
          <tr>
            <td class="csstyle2" height="0"><a href="Dept/Laboratory.htm"></a> <strong><a href="http://172.16.64.22:8080/" target="_blank"> Login to Department Library</a></strong></td>
          </tr>
          <tr>
            <td class="csstyle2" height="0"><strong><a href="http://library.cusat.ac.in/" target="_blank">University Library</a></strong></td>
          </tr>
          <tr>
            <td class="csstyle2" height="0"><strong><a href="http://opac.cusat.ac.in/" target="_blank">Search OPAC</a></strong></td>
          </tr>
        </tbody></table>
        <br>
		  </td>
                </tr>
                
              </tbody></table></td>
        </tr>
        <tr> </tr>
      </tbody>
    </table></td>
  </tr>
            </tbody>

        </table>
    </div>
</body>
</html>