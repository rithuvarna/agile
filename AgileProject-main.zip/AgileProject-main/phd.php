<!--include the navbar-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DCS WEBSITE</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/style1.css" rel="stylesheet">
  <link href="assets/css/adstyle.css" rel="stylesheet">


  <!-- =======================================================
  * Template Name: Maxim - v4.7.0
  * Template URL: https://bootstrapmade.com/maxim-free-onepage-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<body>
    <?php include('navigation.php'); ?>
    <div class="div1 ">
        <table>
            <tbody>
            <tr>
    <td colspan="20"><table width="100%" cellspacing="0" cellpadding="0" bordercolor="#1bac9" border="1" >
      <tbody>
        <tr>
          <td><table width="100%" cellspacing="0" cellpadding="0">
                <tbody><tr>
                  <td valign="top" height="0" align="left">
				  



        <br>
        
<table width="90%" border="0" align="center">
  <tbody><tr> 
    <td class="csstyle2" width="100%"><strong> Ph.D</strong></td>
  </tr>
  <tr> 
    <td class="csstyle2"><div align="justify">The Department came into existence 
        in 1984 with an M.Tech. Programme in Computer and Information Science. 
        In addition to this it has an M.Tech. programme in Software Engineering. 
        The Department also conducts research leading to Ph.D. in several areas 
        of computer science including Artificial Intelligence, human computer 
        interaction, Intelligent architectures and Software Engineering.<br>
        <strong>Core Areas of Research</strong> <br>
        Natural Language Processing, Theoretical Computer Science, Distributed 
        Computing, Information Systems Engineering, Computer Networks, Mobile 
        Computing</div></td>
  </tr>
  <tr> 
    <td class="csstyle2" height="0"><strong><a href="phdlist.php"> 
      Ph.D's Produced (Past 10 Years) </a></strong></td>
  </tr>
</tbody></table>
        
<br>

		  </td>
                </tr>
               
              </tbody></table></td>
        </tr>
        <tr> </tr>
      </tbody>
    </table></td>
  </tr>
            </tbody>
        </table>
    </div>
</body>
</html>