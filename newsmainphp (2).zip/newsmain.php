<?php include('nav.php');  ?>
<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="newsmain.css">
</head>
<body>
<span id="disp-record">        <div>
                            <div class="ho-event pg-eve-main">
                            <div class="card ">
              
			  <div class="card-content">
                                                                <ul>
                                                                    <li>
                                       <div class="news-img"> JUNE 5</div>
                                        <div class="ho-ev-link pg-eve-desc">
                                           <a href="news.php" >
                                                <h4>WORLD ENVIRONMENT DAY</h4>
                                            </a>
                                           <br>
                                           
                                        </div>
                                        <div class="pg-eve-reg">
                                            <a href="news.php">Read more </a> 
                                        </div>
                                    </li>
                                                                     

                                                                      
                                                                     
                                                                      
                                                                       
                                                                      
                                                                       
                                                                     
                                                                       
                                                                      
                                                                      
                                                                      
                                                                       
                                    
                                                                       
                                                                       
                                                                   </ul>
                                                                </div>
                                </div>
                            </div>
                                </div></span> 
</body>
</html>



<?php	include('footer.php'); ?>